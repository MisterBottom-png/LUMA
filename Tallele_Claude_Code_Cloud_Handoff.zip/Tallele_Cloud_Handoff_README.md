# Tallele / Claude Code cloud handoff

This package contains:
- `Tallele_Limestone_Harbour_Claude_Code_Prompt.md` — full implementation and subagent instructions.
- `tallele-limestone-harbour-proposal.md` — the approved v1.3 design.
- `tallele-backgrounds.zip` — original ten PNG backgrounds. These are **source images**, not yet Android WebP drawables.

## Android workflow

1. Connect GitHub to Claude Code's cloud sessions in the Claude app's Code tab (or use https://claude.ai/code). Select `MisterBottom-png/LUMA`, `main`.
2. Make **this bundle** available in that GitHub repository, e.g. upload it directly as `Tallele_Claude_Code_Cloud_Handoff.zip` at the repository root, which is easiest from an Android browser. Alternatively attach the three files directly to your Claude Code session, if that UI supports it. Files attached to a different ChatGPT conversation are not automatically visible to Claude Code.
3. In a cloud Code session, paste this short launcher:

   Implement P0 of the Tallele Limestone Harbour redesign from `Tallele_Claude_Code_Cloud_Handoff.zip` in the repository root. Extract the bundle into a temporary directory, read `Tallele_Limestone_Harbour_Claude_Code_Prompt.md` and the attached v1.3 design, and inspect the background source ZIP. Follow the master prompt literally: use bounded subagents, verify current `main` and Android build access, establish baseline tests, commit handoff documents, push a phase branch, and stop at the P0 review gate. Do not begin P1.

4. Review the P0 changes in Claude's diff/PR. Only after merging the reviewed phase, start a **new** cloud session on `main` and paste the continuation instruction in the master prompt.
5. Android SDK is not guaranteed in the cloud VM; the prompt requires verifying it and configuring a reproducible build/CI rather than pretending tests were run. Physical-device visual/notification testing remains an owner-side task.

The bundle is a handoff package; **do not** extract original raw PNGs as runtime drawables or permanently copy its original 15 MB archive into `app/src/main`. The implementing agent converts the source PNGs into optimized WebP resources and measures the APK result.
