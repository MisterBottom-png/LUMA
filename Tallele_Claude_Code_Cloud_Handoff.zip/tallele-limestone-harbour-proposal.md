# Tallele — Final Redesign Proposal: Limestone Harbour

**Version:** 1.3 · 14 October 2026
**Status:** Final design direction, ready for a clickable prototype. Not yet built or tested on a phone.
**App:** Tallele (repository `MisterBottom-png/LUMA`, branch `main`, commit `43a16428d070523e7aed516c69a5db8173adaa43`)
**Built on:** *Tallele — Consolidated UI & UX Redesign* ("Limestone Harbour"), which merged three earlier proposals: Harbour, Oxblood & Linen, and Limestone & Ink.
**Design canvas:** "Tallele — Limestone Harbour" (a style sheet, a map and 15 phone screens).

---

## 0. Owner decisions

These decisions are final. They win over anything else in this document or in the source proposals.

| Topic | Decision | What it means |
|---|---|---|
| Week strip | **Remove it from the Capture screen.** | Capture shows a small **Today** link instead. The week row lives inside Calendar. Adding a thought for a date starts from Calendar. |
| Glass | **Keep it.** | The tab bar is **glass by default**: see-through with blur on phones that support it. It falls back to Frosted or Solid. Lists, cards, sheets and dialogs always stay solid. |
| Reset | **Erase everything.** | Reset deletes all items, Spaces and reminders, plus settings, the Gemini key, learned rules and AI history. The code must change to do this. |
| Old appearance settings | **Remove them.** No "Advanced" section. | Appearance keeps only Theme, Accent (4 checked colours), Background and Tab bar. Old values are converted once to the nearest new choice. |
| Backgrounds | **A choice of built-in backgrounds** instead of your own photo. | A small set of calm images made for Tallele, each with a light and a dark version. They show on Capture only. |
| Kept thoughts *(earlier decision)* | Kept thoughts count as **"waiting"** in Needs you. | They show in Needs you under "Waiting to be sorted · optional". They do **not** count on the tab badge. |
| Space "+" *(earlier decision)* | A Space's "+" opens its own capture screen. | Unclear thoughts and reminders without a time get a question card right there. The card looks the same as in Needs you. |

---

## 1. The design on one page

**What Tallele is:** a private, local-first place to put a thought down. It is not a task dashboard and not a calendar app.

**Three tabs, one job each:**

| Tab | Question it answers | What lives there |
|---|---|---|
| **Capture** | Where do I put this? | Writing box, Voice, Keep, the receipt, a Today link |
| **Saved** | Where is that thing? | Search everything, Spaces, Kept thoughts, Calendar, Archived |
| **Needs you** | What do I need to decide? | To decide, Waiting to be sorted (optional), Look after, Ask Tallele |

**Four promises:**
1. Writing is quick. No type, date, Space or title is needed before Keep.
2. "Kept on this device" appears only after the thought is really stored.
3. Anything you kept can be found again in Search, including thoughts you haven't sorted.
4. Automatic filing is always visible and always has Undo or Change.

**The look:** warm limestone paper, blue-black ink, your own words in the Literata serif, the app's words in Noto Sans. Solid surfaces everywhere except the glass tab bar.

---

## 2. What changed from the source proposal

| Topic | Source proposal said | This version |
|---|---|---|
| Week strip | No permanent strip on Capture | Same: removed (owner decision) |
| Tab bar | Solid by default; maybe a near-solid see-through bar after testing | **Glass by default**, with Frosted and Solid as fallbacks (owner decision) |
| Reset | Check what Reset deletes before showing "erase everything" | **Erase everything**; the code changes to match (owner decision) |
| Optional sorting in Needs you | "Suggestions · optional" | Named **"Waiting to be sorted · optional"** to keep the owner's "waiting" idea. It still does not count on the badge. |
| Space "+" | Space detail has "Add to this Space" | That button opens a full **Add to [Space]** capture screen with the shared question card |
| Old appearance settings | Keep them in an "Advanced personalisation" view | **Removed**, with a one-time conversion (owner decision) |
| Backgrounds | Keep existing photo backgrounds | **Built-in backgrounds only**, no own photo (owner decision) |
| Everything else | — | Kept as written: tabs, search scope, receipt, Undo, colours, fonts, build plan and checks |

---

## 3. Where things live

```text
Capture  (opens first)
├─ Writing box: type, Voice, shared text, launcher shortcut, Quick Settings tile
├─ Receipt: kept → filed / asking / blocked / waiting, with Undo where it really works
├─ Today link → Calendar on today
├─ Search (icon) → Search
├─ Settings (icon) → Settings
└─ Several thoughts (Brain Dump) → opens from the receipt when one entry holds many thoughts

Saved
├─ Search everything you kept → Search results
├─ Shortcuts: Calendar · Kept thoughts · Archived
├─ Your Spaces → Space detail → "+" Add to [Space]
│   ├─ Unfiled (finished items with no Space)
│   └─ Hidden and archived Spaces (folded, can be restored)
└─ Recently saved

Needs you
├─ To decide            ← only these count on the badge
├─ Waiting to be sorted · optional  → Sort one by one
├─ Look after: From earlier · Still open · Quiet for a while · Waiting for · Someday · Weekly look back
├─ Ask Tallele (button in header): Ask / Overview
└─ ⋮ menu: Take one calm breath

Shared screens: Item and reminder detail · Sort sheet · Calendar · Settings
```

**Three things the design must keep apart:**

- **Kept thought ≠ Unfiled.** A kept thought is your raw words, not sorted yet. An Unfiled item is a finished note, task or reminder that has no Space. Both are saved, and they are not duplicates.
- **To decide ≠ Waiting to be sorted.** A reminder with no time needs a decision. A suggestion to file a thought does not. Badges, counts and notification text must never mix them.
- **Due ≠ Notify.** A reminder can be due at 09:00 and notify at 08:45 (15 minutes early) and repeat weekly. Show each one separately. Never call a kept thought "scheduled".

**Back behaviour:** a pushed screen (Calendar, Search, Space, item detail) returns to where you came from, with the same tab, scroll position, filters and selected date. Search keeps its query when you come back from a result. Every existing deep link (notifications, share, item, reminder, shortcut, tile) must keep working.

---

## 4. The four main journeys

### A. Capture, then let go
1. Open Capture (or the launcher shortcut, the Quick Settings tile, share text, or "Add for this date" in Calendar).
2. Type or speak. Nothing else is required.
3. Tap **Keep**. The raw text is stored first.
4. The receipt says **"Kept on this device."** The box empties and keeps focus for the next thought.
5. Sorting happens after this and updates the same receipt. You can leave at any time.

If storing fails: "Couldn't keep that. Your text is still here." plus **Try again**. The text is never cleared on failure.

### B. Find anything again
1. Saved → Search (or the search icon on Capture).
2. Type a word you remember.
3. Results come in groups: Tasks, Reminders, Notes, **Kept thoughts**, and Archived (only when you include it).
4. Open a result. Back returns to the same query, filters and scroll position.

A thought that has already been sorted appears once, as its finished item, never twice.

### C. Fix a reminder
1. The receipt or Needs you → To decide shows one card: **"Missing a time"** with the thought.
2. Pick a quick time (only valid future times are offered) or **Pick date & time**.
3. The result shows due time, notification time, repeat and whether it is really scheduled.
4. **Keep without a reminder** leaves the thought safe. If a linked reminder already exists, say that it will be cancelled before doing it.

"Scheduled" is shown only when the scheduling state says so. If notifications are off, show "Notifications are off" with **Turn on**. Android can still deliver late, so the words never promise an exact ring time.

### D. Sort when ready
1. Needs you → Waiting to be sorted, Saved → Kept thoughts, or **Change** on a receipt.
2. The sort sheet shows your original words first, then the suggestion: type, Space, optional date.
3. The main button names the result: **Create task**, **Save note** or **Set reminder**. The second option is **Keep as a thought**.
4. **Why?** gives plain facts ("Because it says 'tomorrow at 9' and mentions the dentist. Sorted on this device."). It never shows a confidence percentage.

### How a capture moves through states

```text
Writing (not saved yet)
   │ Keep
   ▼
Saving on this device ──[fails]──► Text stays + Try again   (never "Kept")
   │ stored
   ▼
Kept on this device ──► you can write the next thought straight away
   │ sorting runs after this (not part of the save promise)
   ├─► Kept thought: not sorted; searchable; "waiting" in Needs you
   ├─► Filed as note/task: result + Space + Change + Undo (where safe)
   ├─► Reminder scheduled: due + notify + real scheduling state
   └─► Needs a decision / blocked: one reason + one direct fix

Rule: Undo or your own edit always wins over late sorting.
```

---

## 5. Receipt wording

The first line always says what is stored. The second line says what happened after that.

| What really happened | First line / second line | Actions |
|---|---|---|
| Stored, sorting still running | "Kept on this device." / "Organising…" (only while it is really running) | Open |
| Stored, kept as a thought | "Kept on this device." / "Still a thought. You can sort it later." | Open · Sort now |
| Filed automatically as a note or task | "Kept on this device." / "Created a task in Household." (the real result) | Open · Change · Undo · Why? |
| Reminder needs a time | "Kept on this device." / "Choose a time to set the reminder." | Quick times · Pick date & time · Keep without a reminder |
| Reminder really scheduled | "Kept on this device." / "Reminder scheduled: Wed 14 Oct, 09:00 · Health" | Open · Change · Undo · Why? |
| Notifications are off | "Kept on this device." / "Notifications are off. This reminder can't notify you yet." | Turn on · Open |
| Scheduling failed after storing | "Kept on this device." / "The reminder could not be scheduled. Your thought is safe." | Try again · Edit |
| Gemini failed, local sorting used | "Kept on this device." / "Suggestions weren't available. You can sort it yourself." | Sort |
| Storing failed | "Couldn't keep that." / "Your text is still here." | Try again |
| Several thoughts in one entry | "Kept on this device." / "Kept 7 thoughts. Sort them now or later." | Sort now |

**Undo rules**
- Undo must map to a real, tested rollback. After automatic filing, Undo returns the item to a kept thought and stops late sorting from filing it again.
- If the filed item has been edited or completed since, hide Undo and offer Change or Open instead.
- A plain kept thought gets no Undo, because undoing a save would mean deleting.
- The receipt stays until the next Keep or until you dismiss it. TalkBack gets a "Hide" action instead of a swipe.

---

## 6. Visual system

### 6.1 Colour

Each colour has one job. The values come from the Limestone & Ink token tables, which were checked against WCAG 2.x. Re-check them in the real app.

| Token | Job | Light | Dark |
|---|---|---|---|
| page | Screen background | `#F3F1EC` | `#121417` |
| surface | Lists, cards, capture box | `#FBFAF7` | `#1A1D22` |
| sheet | Bottom sheets, dialogs | `#FFFFFF` | `#22262C` |
| well | Search field, inputs | `#EAE7E0` | `#0D0F12` |
| text | Main text | `#1B1F27` | `#ECEAE4` |
| text-2 | Secondary text, icons | `#4F5562` | `#B4B7BE` |
| text-3 | Placeholders | `#5F646E` | `#9A9EA7` |
| hairline | Decorative dividers | `#DDD9D0` | `#2C3037` |
| outline | Edges of inputs, chips, checkboxes | `#8A8780` | `#6F747D` |
| ink (accent) | Keep, selected tab, links, focus | `#2D4B7E` | `#A8BFE8` |
| on-ink | Text on ink | `#FFFFFF` | `#0F2147` |
| ink-soft / on-ink-soft | Selected chip, selected tab pill | `#E0E7F3` / `#1A2D50` | `#263A5E` / `#DCE6F8` |
| ochre (signal) | Only when a choice is needed | `#8A5300` | `#E6B566` |
| ochre-soft / on-ochre-soft | Behind a decision's reason | `#F4E4C9` / `#3F2600` | `#3B2B12` / `#F6DDB2` |
| success | Done, scheduled | `#2F6B3F` | `#93C6A0` |
| error / error-soft | Failures and erasing only | `#A3302A` / `#F7DEDA` | `#F2A49C` / `#4A1F1C` |

**Colour rules**
1. Ink appears only on Keep (or the main button), the selected tab, links and the focus ring.
2. Ochre appears only where a choice is needed. Never as decoration.
3. Red appears only for errors and erasing.
4. A colour never carries meaning alone. There is always a word or an icon too.
5. No gradients anywhere.
6. Only the tab bar is see-through.

**Space colours** are used only as a 10 dp square and an icon tint, always next to the Space name: Slate `#5B6B82`, Moss `#5A7A4E`, Clay `#9A5B44`, Sand `#7D6A4A`, Plum `#7A5582`, Harbour `#2F7178`, Rose `#9C4F62`, Stone `#6F6A60` (light theme values).

### 6.2 Type

Two voices: **your words** in Literata, **the app's words** in Noto Sans. Both cover Latin, Estonian and Cyrillic, so Russian looks the same as English.

| Role | Font | Size / line (sp) | Weight |
|---|---|---|---|
| Screen title | Noto Sans | 24 / 32 | 600 |
| Item title | Literata | 24 / 34 | 500 |
| Capture text | Literata | 20 / 30 | 400 |
| Your words in lists | Literata | 17 / 26 | 400 |
| Body and controls | Noto Sans | 15–16 / 23 | 400–600 |
| Metadata | Noto Sans | 14 / 20 | 400 |
| Tab labels | Noto Sans | 12–14, grows as needed | 600 |

- No all-caps text. No light weights. Nothing important below 13 sp.
- Times use tabular numbers so they line up.
- Fonts are bundled in the app, never loaded from the network. Include the OFL licence files.
- Noto Sans replaces Google Sans Flex, which has no Cyrillic. Check the package size.
- Test Literata at 17 sp on small, low-density screens. If it scans slowly, consider a sans option for list rows.

### 6.3 Layout and shape

- 4 dp grid: 4, 8, 12, 16, 20, 24, 32, 48.
- Side margins: 20 dp, or 16 dp on screens narrower than 360 dp.
- Every control has a touch area of at least 48 × 48 dp.
- Rows grow with text size and never clip.
- Ordinary lists use rows with dividers. Cards are only for the capture box, decisions and important status.
- Corners: capture box 20 dp, cards 12 dp, chips and small buttons 8 dp, sheets 24 dp at the top, tab bar 20 dp.
- A thin 2 dp ink line runs down the left side of the capture box and the receipt. It is the visual link between what you wrote and what was kept.
- Scrolling lists end with enough space that the last row clears the tab bar.

### 6.4 Glass (owner decision: keep)

Glass is used on **one** thing: the floating tab bar.

| Tab bar setting | Look | When it is used | Checked contrast (tab labels, light / dark)* |
|---|---|---|---|
| **Glass** (default) | Surface colour at 84% plus blur | Phones with Android 13 or newer, animations on, not in battery saver | 5.2 / 5.3 |
| **Frosted** | Surface colour at 94%, no blur | Automatic fallback on Android 12 and older, in battery saver, or with animations off | 6.4 / 7.3 |
| **Solid** | Surface colour at 100% | When the person picks it | 7.2 / 8.4 |

\*Worst case, from Limestone & Ink: full-strength main text directly under the bar with no blur.

**Glass rules**
- Lists, cards, sheets, dialogs, menus, snackbars and editors are always solid.
- No glass cards, no blur inside lists, no stacked blur layers, no shine or noise on top.
- Use the existing Haze 1.7.2 setup for this one surface. Measure performance on a real mid-range phone.
- A built-in background (section 7.17) shows on Capture only. Each image has its own fixed wash of the page colour, tuned so text over it passes contrast. The Limestone & Ink calculation used 86% as the safe worst case. Because the images are calm and known in advance, each one can be checked once and given a lighter wash if it still passes.

### 6.5 Motion

| Name | Time | Used for |
|---|---|---|
| quick | 120 ms | Small colour and opacity changes |
| settle | about 200–240 ms | The thought settling into the receipt after Keep |
| move | about 300 ms | Opening a screen; follows predictive Back |
| tabs | 180 ms fade | Switching tabs, no sliding |

- No bounce, no confetti, no flying text, no looping animation.
- Nothing depends on an animation finishing.
- With "Remove animations" on (checked every time the app comes to the front), every movement is instant, the tab bar uses Frosted, and Take one calm breath shows its steps as text.
- One short haptic tick on Keep. None on ordinary taps.

### 6.6 Icons and the keep mark

- One outlined icon family, 24 dp in controls and 20 dp inline. The selected tab may use a filled version.
- **Keep mark:** a dot settling into a shallow tray. It means "put away for safekeeping" and appears on the Keep button, the receipt, the notification icon and the app icon.
- Tab icons: Capture = pen on a line, Saved = bookmark, Needs you = inbox tray.

---

## 7. Screens

Each screen lists its job, what is on it, the main actions, the wording and its states. The shared state rules in section 8 apply to every screen.

### 7.1 Capture (tab 1, opens first)
- **Job:** keep a thought in one tap.
- **Layout, top to bottom:** "Tallele" in Literata with Search and Settings icons on the right. An optional greeting under it, only when a name is set ("Good evening, Anna"). The invitation "Put it here." The capture box: surface colour, 20 dp corners, ink margin line, Literata 20/30, at least four lines tall, grows and then scrolls. **Voice** on the left and **Keep** on the right. Under the box, the first-run line or the receipt. At the bottom, a **Today** card (solid surface, hairline edge, 12 dp corners): "Tuesday 13 October · 3 things" with "Open calendar →". It is a card so it stays readable over any background. Then the glass tab bar. When a background is chosen (7.17), it sits behind all of this; the capture box, receipt and Today card stay solid.
- **No week strip, no task list, no counts, no rotating prompts.**
- **Actions:** Keep; Voice; Search; Settings; Today → Calendar.
- **Words:** placeholder "A thought, a plan, something to remember…". First-run line "Kept on this device when you tap Keep. Sorting can follow." With Gemini on, add "Gemini is on: what you keep is sent to Google to sort." Disabled Keep hint: "Write something to keep it." Estonian Keep: „Pane tallele“.
- **Keyboard:** the tab bar hides, the box sits above the keyboard, Keep stays visible. Enter makes a new line; saving is always a tap on Keep.
- **Date or Space context:** coming from Calendar or a share adds a removable chip in the box, for example "For Thu 15 Oct ×".
- **States:** empty; keeping (over 300 ms: "Keeping…" in the button); all receipt states from section 5; offline works the same.
- **Accessibility:** box labelled "New thought"; Keep labelled "Keep thought"; the receipt is a polite live region and is read once.

### 7.2 Voice
- Tap Voice: "Listening…", words appear in the box, tap again to stop. It never keeps anything by itself.
- When on-device speech isn't available, show the existing one-time notice: "Voice may use your phone's speech service, which can send audio to its provider." Continue / Cancel.
- Errors: "Nothing heard. Try again or type." · "Voice isn't available on this phone right now."
- Microphone permission is asked only when Voice is first tapped. Denial leaves typing fully usable.

### 7.3 Several thoughts (Brain Dump)
- **Opens from:** the receipt ("Kept 7 thoughts. Sort them now or later.") or a kept Brain Dump in Saved.
- **Layout:** back, title "Several thoughts", ⋮ (Keep together as one note, Discard the rest). The line "Your original words stay kept. Tick the ones you want to save." A list where each row has a 48 dp tick, your words in Literata, a fact line ("Task · Household"), and an Edit target. A row that needs a time shows "Needs a time · not scheduled" in ochre with **Choose time**. A bottom bar holds **Save 2 selected** and **Finish later**.
- **Rules:** start with this overview, not a one-by-one wizard. Keep the cautious default selection. Each row saves exactly once. Partial success keeps failed rows here to try again. Split only happens when the person chooses it.
- **Words:** "Only ticked rows are saved. If one fails, it stays here so you can try again." End: "3 saved · 1 kept · 1 skipped". Never "Everything handled".
- **One by one:** the sort sheet with "Thought 3 of 7", Skip with Undo, Keep as a thought, Discard the rest (with confirmation).
- **Accessibility:** tick and Edit are separate targets; each tick reads "Save 'Order potting mix'"; the result is announced as "2 saved; 1 still needs a time."

### 7.4 Sort sheet (one thought)
- **Opens from:** Change, Sort now, Pick a time, a Waiting row, or after every Keep when **Review each capture** is on.
- **Order:** your words (editable), "Tallele suggests a reminder." with **Why?**, a "Make it" row (Note · Task · Reminder · Keep as a thought), Space chips (suggested first), a time row that fits the type, labels, the main button named after the result, and "Not now — keep it to sort later".
- **Time rows:** Task "When": No date, Today, Tomorrow, Pick a date. Reminder "Remind me": the suggested time, Tomorrow 09:00, Pick… A reminder needs a valid future time.
- **Words:** low confidence: "Not sure what this is yet. Pick one, or keep it to sort later." No suggestion: "Couldn't suggest anything this time. Your thought is safe."
- **States:** suggestion loading shows two placeholder lines in that area only, and the type buttons always work. This loading state is defined in the code today but never drawn.
- **Back** closes the sheet and keeps the thought, the same as "Not now".

### 7.5 Add to a Space (Space "+")
- **Job:** capture straight into one Space (owner decision).
- **Layout:** back, the Space colour square, title "Add to Health". The same capture box with a removable "In Health ×" chip, Voice and Keep.
- After Keep, the receipt says "Kept on this device · in Health". If Tallele needs a type or a time, the **same decision card as Needs you** appears right under it: for example "Should this be a task?" with Task, no date / Task, pick a date / Keep as a thought, or "When should this remind you?" with times / Keep without a reminder.
- Uses the existing `suggestedSpaceId` path in `CaptureInbox.save`.

### 7.6 Saved (tab 2)
- **Job:** find what you kept.
- **Layout:** title "Saved"; search field "Search everything you kept"; shortcut chips **Calendar**, **Kept thoughts · 4** and **Archived**; "Your Spaces" as rows (icon tinted with the Space colour, name, open count and the next or latest item); an **Unfiled · 2** row ("Finished items with no Space"); **New Space** and **All 6 Spaces**; "Recently saved" (up to five rows, with See all).
- A sorted thought never shows next to its finished item.
- **Empty:** "Nothing saved yet. Write something on Capture." Spaces empty: "Spaces are optional. Make one when it helps."
- **Accessibility:** the search field is the first focus after the title; counts read as "2 open".

### 7.7 Search
- **Layout:** back, the field with Clear, filter chips (All · Tasks · Reminders · Notes · Kept thoughts · Archived), a result count, then groups. Matched words are underlined and tinted, so the match does not depend on colour.
- **Scope (behaviour change):** kept thoughts are included **by default**, in their own "Kept thoughts" group. There is no opt-in switch. Archived appears only when chosen.
- **Matching stays as it is:** on the device only, every word must match, case and accents are ignored, results update after a short pause (150 ms). It does not search by meaning, and no screen should say it does.
- **Before typing:** recently kept items, Space shortcuts, and Ask Tallele question chips. "Search stays on this device."
- **No results:** "No matches for 'dentist'." with **Search archived too**, **Clear filters** and **Ask instead**.
- Never show "No results" while a newer search is still running. The result count is announced once typing stops.

### 7.8 Kept thoughts list
- Opens from the Saved chip. Newest first. Each row shows your words, when it was kept, and the suggestion if there is one.
- Actions: Open, Sort, Hide suggestion, Let it go (with Undo), Resume Brain Dump.
- **Words:** "Kept here until you need it." Empty: "No kept thoughts. Everything is sorted."

### 7.9 Space detail
- **Header:** back, the Space name with its colour square, "5 open · 3 notes", **+** (opens Add to [Space]) and ⋮ (Edit, Hide, Archive).
- **Sections:** Today, From earlier, Upcoming, No date, Notes, then "4 done · Show". Optional filters: All · Tasks · Notes · Reminders.
- Tasks have a 48 dp tick. A ticked item stays in place, struck through, until you leave, with Undo.
- **Move:** row menu → "Move to…" listing Spaces and Unfiled, then "Moved to Work." with Undo.
- **Hide / archive words:** "Off the list for now. Items stay where they are." · "For a Space you are done with. Items stay."
- Reordering uses Move up / Move down, never drag only.
- **New / Edit Space:** name first, a live preview, colour and icon folded underneath. Name clash: "You already have a Space called Work." with **Restore it** when that Space is hidden.

### 7.10 Calendar
- **Opens from:** the Today link on Capture, the Calendar chip on Saved, Look after, or a notification. It is a pushed screen with a back arrow, not a tab.
- **Header:** back, "October 2026 ▾" (opens Go to date), **+** for this day, a Day | Month switch, and Today when you are away from today.
- **Day view:** a week row (the week strip now lives here), the date ("Tuesday 13 October · Today · 4 things"), then **Any time** and **At a time** groups. Times line up in a column. An ink "now" line shows on today. Done items are greyed and struck through. Reminders show "notify 19:15" as the second line. At the bottom: **Add for 13 October**, which returns to Capture with the date chip.
- **Month view:** six rows, days from neighbouring months greyed and tappable, one dot under days with items, and the selected day's list under the grid. On screens narrower than 360 dp or at large text sizes, use a list or date picker instead of squeezing the grid.
- **Rules:** a repeating reminder's future dates open the one real reminder. No events, durations or outside calendar sync. Date-only notes stay date-only, never "00:00".
- **Words:** empty day: "Nothing planned." with **Add to this day**.

### 7.11 Item and reminder detail
- **One shared screen** for notes, tasks, reminders and kept thoughts.
- **Layout:** back and ⋮; your words as the title (Literata 24/34) and body (Literata 17/26); a line with type, Space and "from a kept thought" when that link exists.
- **Reminder:** a status line first ("✓ Reminder scheduled", or in ochre "Notifications are off" with **Turn on**, or "May ring a few minutes late" with **Allow**). Then separate rows: **Due**, **Notification** (time plus "15 minutes before"), **Repeat**, **Space**. Each row opens its own editor.
- **Task:** Mark done / Reopen, status (Active · Waiting for · Someday · Done), due date, Space, **Make it smaller**.
- **Note:** read first, Edit, Space, optional date, Archive.
- **Kept thought:** read-only text, main button **Sort this thought**, **Resume Brain Dump** when one is waiting.
- **Main action** sits at the bottom: Mark done, Reopen or Restore. "Created 12 Oct · Updated today 18:31" goes under it.
- **Editing:** tap to edit, with Save / Cancel. Back with unsaved changes asks "Discard your changes?" (Discard / Keep editing).
- **Delete:** "Delete this task?" / "It will be gone for good. To keep it out of sight, archive it instead." Buttons: Delete task / Keep task. Reminders cannot be archived, so they have Delete only, with "It will stop reminding you."
- **Live updates:** the screen updates if the item changes elsewhere, for example Done from a notification.
- **Editors:** Due (date only or date and time; Today / Tomorrow / pick), Notify (at the time, 5, 15 or 30 min, 1 hour or 1 day before; preview both times), Repeat (none, daily, weekdays, weekly, monthly: "When you mark it done, Tallele moves it to the next time."), Type change (explains what will be lost; keeps Undo), Move.

### 7.12 Needs you (tab 3)
- **Job:** decide only what really needs you.
- **Header:** "Needs you", an **Ask** button, ⋮ with **Take one calm breath**. The line "Only what really needs a choice."
- **Sections, in fixed order (empty ones hidden):**
  1. **To decide · 2** (ochre): one card shape for every decision: the reason in ochre with an icon, the thought in Literata, the answers, and **Keep without a reminder** (or **Keep as a thought**). Reasons: Missing a time, Time has passed, Notifications are off, Couldn't set the reminder, Should this be a task?
  2. **Waiting to be sorted · optional**: kept thoughts with their suggestion ("Looks like a task · Household") and a one-tap **Save**, or **Sort** when there is no suggestion. Header action **Sort one by one**. **Accept all** shows a confirmation that names the exact items and has Undo. Thoughts with a missing time are never in Accept all.
  3. **Look after**: From earlier (move to tomorrow, choose date, keep without a date, mark done), Still open, Quiet for a while, Waiting for, Someday, Weekly look back.
- **Badge:** counts **To decide** only. Hidden at zero. TalkBack reads "Needs you, 2 to decide".
- **Empty:** "Nothing needs a decision." This stays true even when optional sorting exists.
- No streaks, scores, red overdue counts or guilt words.

### 7.13 Look after lists, Weekly look back, Breathe
- Each list is a pushed screen with a one-line explanation ("Tasks waiting on someone else") and rows. Still open keeps **Keep active** as a visible button.
- **Make it smaller** shows its suggestion under the row with "Suggested on this device" or "Suggested with Gemini" and a **Make it a task** button. It creates nothing until tapped.
- **Weekly look back:** three pages (Look back, Loose ends, Look ahead) with "1 of 3" in words. Loading: "Looking back over your week…". The local fallback line stays: "This week can be noticed without being measured."
- **Take one calm breath:** keep the timing the code uses today. The source proposals disagree on the numbers, so check them in the code. With animations off, show the steps as text.

### 7.14 Ask Tallele
- **Opens from:** the Ask button in Needs you, question chips in Search, and "Ask instead" when Search finds nothing.
- **Layout:** a full-height sheet titled "Ask Tallele" with Close and two modes, **Ask** and **Overview**. Ask has the field "Ask about what you've kept" (a counter appears near the 140-character limit), preset questions as chips, and the answer card labelled "Answered on this device" with a **From** list of source items. Overview shows "Right now", "What matters" and "What's stuck".
- **Words:** footer "Based only on your saved items. Answers never change them." No match: "Nothing you've kept mentions that." with **Search for '…'**. Error: "Couldn't answer right now. Nothing was changed."
- Ask answers locally today. Don't claim Gemini answers unless the code really uses it.

### 7.15 Settings home
- **Opens from** the Settings icon on Capture. A pushed screen with no tab bar.
- **Rows, each with its current value:**
  - Your name: "Anna · shown on Capture"
  - Capture and reminders: "Review each capture: Off · Nothing is blocking reminders"
  - Appearance: "Follow system · Limestone Harbour · Glass"
  - Language and time: "System · 24-hour"
  - AI and privacy: "On this device only"
  - Your data: "Backup · restore · erase everything"
  - About Tallele: "First-time guide · licences · version"
- **Privacy note at the bottom:** "Your things are stored on this device. Gemini is optional and asks you first. Keeping something here is not a backup."
- If saving a setting fails, show the old value again with **Try again**. Never show a failed change as saved.

### 7.16 Capture and reminders
- **Reminder health first:** "Nothing is blocking reminders." with a check, or, in ochre, the single biggest problem with one button ("Notifications are off, so reminders can't ring." **Turn on**). The status is re-checked when you come back from Android settings.
- **Review each capture** (renamed from "Sort right after saving"; same stored value, same effect):
  - Off: "Tallele files clear thoughts by itself, then shows Undo on the receipt."
  - On: "Tallele files nothing by itself. It asks after each thought."
- **Open the keyboard on Capture.**

### 7.17 Appearance
One screen, four choices, no "Advanced" section (owner decision).

- **Theme:** System · Light · Dark.
- **Accent:** four colours, each checked in both themes. Shown as named round swatches.

  | Accent | Light | Dark |
  |---|---|---|
  | Ink (default) | `#2D4B7E` | `#A8BFE8` |
  | Harbour | `#1F5F66` | `#8FCDD3` |
  | Moss | `#3D6136` | `#A9CB9C` |
  | Plum | `#69406F` | `#D6B4DC` |

- **Background ("Shown on Capture"):** None (plain limestone paper, the default) plus five built-in images: Limestone, Harbour mist, Ink wash, Pine fog, Linen light. Each image has a light and a dark version, and the app picks the one that matches the theme. Shown as a grid of named thumbnails. There is no own-photo option, no photo picker and no blur slider; the images are already soft.
- **Tab bar:** **Glass** (default), **Frosted**, **Solid**. The line under it changes with the choice: "See-through with blur, on phones that support it." · "Softly see-through, no blur." · "Plain, easiest to read." Followed by: "Lists, cards and sheets always stay solid."
- **Reset appearance:** "Only the look goes back. Your items stay." This is separate from erasing data.

**Removed for good:** text colour choices, "Use a second color", the gradient background presets (including Violet Mist), your own photo background, the dim slider, surface opacity, dimming mode and the advanced glass sliders.

**One-time conversion** (runs once after the update):

| Old setting | Becomes |
|---|---|
| Ink & Paper, Amber | Ink |
| Ocean | Harbour |
| Sage | Moss |
| Violet, Rose | Plum |
| Any gradient preset, or own photo | Background: None |
| A glass preset that uses blur (for example Strong) | Tab bar: Glass |
| A glass preset without blur | Tab bar: Frosted |
| Glass off / Solid | Tab bar: Solid |
| Text colour, second colour, dim, opacity, dimming mode | Dropped |
| Anything unknown | The default for that setting, never a crash |

Restoring an old backup goes through the same conversion, so old backup files still restore.

**Built-in background rules**
- Calm, soft and low in detail. No text, people, logos or sharp edges.
- Light versions stay pale; dark versions stay deep, so the wash can stay light.
- Shipped inside the app in `res/drawable-nodpi/` as WebP, 1080 × 2400 px (20:9), drawn with crop-to-fill. The whole set of ten files is about 0.9 MB. The source images are 1024 × 1536, so a larger size would add file weight but no detail.
- Resource names use underscores, because Android doesn't allow hyphens: `bg_harbour_mist_light`, `bg_harbour_mist_dark`, and so on.
- The Today row on Capture is a solid card (7.1). That keeps the darker bottom of some images (water, ink, moss) away from text, so the washes can stay light.

**Final set and checked wash values** (delivered in `tallele-backgrounds-android.zip`). Contrast was measured over the top 75% of the screen, where text sits directly on the image. Every value must be 4.5 or more.

| Background | Light wash | Dark wash | Lowest text contrast, light / dark | Lowest accent contrast, light / dark |
|---|---|---|---|---|
| Limestone | 10% | 0% | 5.3 / 8.3 | 5.0 / 9.0 |
| Harbour mist | 40% | 0% | 4.9 / 6.1 | 4.7 / 6.6 |
| Ink wash | 10% | 0% | 5.3 / 7.6 | 5.0 / 8.2 |
| Pine fog | 25% | 0% | 4.9 / 6.2 | 4.6 / 6.7 |
| Linen light | 35% | 0% | 5.0 / 6.1 | 4.7 / 6.6 |

"Lowest text" is secondary text (`text-2`); main text is 10 or more everywhere. "Lowest accent" is the weakest of Ink, Harbour, Moss and Plum. Glass tab-bar labels stay at 6.2 or more (light) and 8.1 or more (dark) over every image.

The values and a ready `TalleleBackground` list with a `CaptureBackground` composable are in the zip. Re-check on a real phone in both themes.

### 7.18 Language and time
- Language: System · English · Eesti · Русский, each written in its own language, with no flags.
- Time format: Device default · 12-hour · 24-hour, with a sample time.
- Long labels wrap instead of being cut off. The choice survives screen rotation and app restarts.

### 7.19 AI and privacy
- Headline: "Tallele works without AI. With your own Gemini key it can suggest more."
- Rows: Mode (On this device / Gemini), Gemini key (masked; Save, Remove, **Test connection**), Use Gemini for (capture suggestions, Make smaller, Brain Dump, Review), Learning, and model names under Advanced.
- Choosing Gemini opens the consent dialog "Allow Gemini?" (Allow Gemini / Stay on this device). It explains what is sent to Google, and separately that automatic filing can happen when Review each capture is off.
- **Fix:** tapping Test connection before giving consent runs the test after consent. It must not switch the mode silently.
- **Learned rules:** Edit and Remove. Remove shows Undo. **Clear learned data** keeps its confirmation, which lists what goes and says that your items stay.

### 7.20 Your data (owner decision: Reset erases everything)
- **Backup:** "Create backup" → "Export readable data? This file isn't encrypted. Anyone who has it can read your items." → choose where to save. Afterwards "Backup saved." and "Last backup: 13 October". Never say saved until the file write is confirmed.
- **Restore:** "Restore from a backup" → "Checking…" → "Replace what's on this device?" showing incoming and current counts → **Replace data** / Cancel. Never call it a merge. If reminders fail to set up afterwards: "Items restored. Reminders need setup." with **Set up reminders again**.
- **Set up reminders again** stays available while it is needed.
- **Erase everything**, placed apart at the bottom under "Start over":
  - Row text: "Erases items, Spaces, reminders, settings, your Gemini key, learned rules and AI history."
  - Dialog title: **"Erase everything on this device?"**
  - Dialog body: "All items, Spaces and reminders go, and so do your settings, Gemini key, learned rules and AI history. Reminders stop ringing. This can't be undone."
  - Link: **Create a backup first**.
  - Buttons: **Keep my data** (outline) and **Erase everything** (red).
  - Afterwards the app starts like a fresh install, on Capture.
  - **Code change needed:** today Reset removes items, Spaces and reminders but keeps settings, the Gemini key, learned rules and AI history (`LocalDataToolsViewModel.kt`). It must also clear the settings store, the encrypted key, learned rules, AI history, receipt state and any saved drafts, and cancel every scheduled reminder and backup worker.

### 7.21 About and first run
- First launch opens straight on Capture with "Kept on this device when you tap Keep." Nothing else is asked first.
- The first automatic filing adds: "Tallele filed this for you. Undo or Change if it got it wrong."
- Notification permission is asked in context, at the first reminder, with a one-line reason.
- About holds the optional four-page guide (Capture, What happens after saving, Spaces, Privacy) with Skip, Back, Continue and "Step 2 of 4", the version, and the licences for Literata and Noto Sans.

### 7.22 Outside the app
- **Notifications:** channel "Tallele reminders"; small icon = keep mark; title = the reminder; text "Due 09:00 · Health"; actions **Done** and **Snooze 15 min**. Snooze moves the notification time, not the due time. Done on a repeating reminder moves it to the next time. When more than three are missed, one summary replaces them: "[N] reminders were missed" / "They're waiting in Needs you."
- **Quick Settings tile and launcher shortcut:** "New thought", keep-mark icon, open Capture with focus.
- **Share target:** "Keep in Tallele". Shared text lands in the Capture box. Nothing saves without a tap.
- **App icon and splash:** limestone background with the ink keep mark. The themed icon is the mark alone.

---

## 8. Shared state rules (every screen)

| State | Do | Don't |
|---|---|---|
| First load | Keep the page shape and show a small loading line if it takes time | Flash "Nothing saved" before the data arrives |
| Saving or changing | Keep the content visible and block only a double tap | Freeze the whole screen |
| Failure | Say what failed, what is still safe, and offer Try again. Keep typed text. | "Something went wrong" with lost text |
| Partial success | Count what worked and what didn't, and offer retry for the rest | Claim the whole Brain Dump or restore worked |
| Offline | Everything local works. Only Gemini features explain they need a connection. | Block local work |
| Permission blocked | Show what it affects and one button to the right Android setting | Show "scheduled" when notifications are blocked |
| Missing item | "This item is no longer available." with Back | Show an empty editor |
| Undo | Undo exactly the named action | Offer Undo that can't really undo |
| Announcements | Announce kept, filed and scheduled once each, politely | Repeat messages or steal focus |

---

## 9. Behaviour changes

Everything else is presentation or navigation. **Not changed:** when Tallele files by itself, the confidence thresholds, reminder scheduling, the data model, the export format and the local-first rule.

| # | Change | Why | Risk |
|---|---|---|---|
| B1 | Automatic filing gets **Undo** on the receipt, returning the item to a kept thought | Tallele already files by itself; one-tap reversal makes that fair | Medium: needs real rollback and race tests |
| B2 | **Kept thoughts appear in Search by default**, in their own group | Anything you kept must be findable. Today Search never includes them. | Medium: query, de-duplication, Brain Dump one-to-many, speed |
| B3 | Truthful receipt for a kept thought ("Still a thought…") and for Brain Dump ("Kept 7 thoughts…") | Today it says "Saved as a note." when no note exists | Low |
| B4 | "Organising…" while sorting is really running | The state exists in code but is never set | Low |
| B5 | **Reset erases everything** (owner decision) | The owner decided Reset should delete everything | Medium: must cover every store and cancel all alarms and workers |
| B6 | Calendar month shows neighbouring-month days, greyed and tappable | Matches the Calendar spec | Low |
| B7 | Notes and tasks with both a date and a time appear on Calendar | Reported to drop off today; **reproduce first** | Low (data bug fix) |
| B8 | Test connection before consent runs the test after consent | It switches the mode silently today | Low |
| B9 | Removing a learned rule shows Undo | It is the only removal with neither a confirmation nor Undo | Low |
| B10 | Item detail updates when the item changes elsewhere | It can show stale facts; **verify first** | Low |
| B11 | Glass tab bar by default, content always solid; old appearance settings removed and converted once; built-in backgrounds replace own photos | Owner decisions; fewer, checked choices look calmer and can all be tested | Medium: conversion, old backups and glass performance |
| B12 | *(Optional)* "From a kept thought · Show the original" on item detail | Helps trust | Touches the "raw thoughts stay private" rule; owner decides |

---

## 10. Build plan

### 10.1 Phases, each with a clear exit check

| Phase | Build | Exit check |
|---|---|---|
| **P0 · Evidence** | Record how the app behaves today: auto-filing, receipt text, drafts, Undo, Reset scope, reminder permissions, the Calendar date-and-time bug, item detail refresh | Baseline tests pass and the findings are written down |
| **P1 · Foundation** | Colour tokens, Literata + Noto Sans, keep mark, shared parts (below), light and dark, glass tab bar with fallbacks | Contrast tests for every pair in both themes; previews at 200% text |
| **P2 · Navigation and finding** | Capture / Saved / Needs you shell; Saved screen; Search with kept thoughts (B2); Calendar as a pushed screen | "Find anything" tests and deep-link tests pass |
| **P3 · Capture and trust** | New Capture without week strip; receipt states (B3, B4); Undo (B1); sort sheet; Several thoughts; Add to a Space | Save, failure, race and partial-success tests pass |
| **P4 · Other screens** | Needs you, Look after, Ask modes, item and reminder detail (B10), Spaces, Calendar fixes (B6, B7) | Reminder-repair, detail and calendar tests pass |
| **P5 · Settings and data** | Settings groups, Appearance (B11), AI fixes (B8, B9), **Erase everything (B5)**, licences, notification and launcher assets | Data-safety tests (export, restore, erase) pass in all three languages |
| **P6 · Check on phones** | TalkBack, large text, small screens, keyboard, reduced motion, glass performance, usability tasks | A written pass/fail report, then the owner approves |

### 10.2 Where the work goes

Paths are under `app/src/main/java/com/orbit/app/`. Do not rename the package as part of this work.

| Area | Files | Change |
|---|---|---|
| Tabs and routes | `ui/navigation/OrbitApp.kt`, `OrbitDestination.kt`, `ui/components/FloatingBottomNavigation.kt` | Three tabs; Calendar off the bar with a back arrow; badge counts To decide only; keep every deep link |
| Capture | `ui/screens/home/HomeScreen.kt`, `HomeCaptureViewModel.kt`, `CaptureReceipt.kt`, `HomeSendFeedback.kt`, `HomeWeekViewModel.kt` | Remove the week strip; add the Today link; new receipt states; clear input only after a confirmed save |
| Auto-filing and sorting | `domain/capture/CaptureDecision.kt`, `AutoFiler.kt`, `CaptureInbox.kt`, `ui/screens/home/CaptureSortHost.kt`, `CaptureSortContent.kt`, `CaptureSortViewModel.kt`, `BrainDump*` | Keep the rules; add Undo through the existing capture link; draw the loading state; keep per-row Brain Dump saving |
| Saved and Search | `ui/screens/spaces/SpacesScreen.kt`, `SpaceCaptureSheet.kt`, `ui/screens/search/SearchScreen.kt`, `SearchViewModel.kt`, `domain/search/LocalSearch.kt` | Saved screen; include kept captures in search; hide processed sources; Space "+" opens Add to [Space] |
| Needs you | `ui/screens/review/ReviewScreen.kt`, `ReviewRedesign.kt`, `ReviewToSortSection.kt`, `ReviewWeekly.kt`, `ReviewViewModel.kt` | New section order; remove the folded "More"; Look after lists as routes; Ask button |
| Ask | `ui/screens/situation/SituationAiSheet.kt`, `SituationAiViewModel.kt` | Ask and Overview modes; entry from Search |
| Calendar | `ui/screens/calendar/*`, `data/repository/CalendarRepository.kt` | Pushed screen; week row inside; B6; B7 |
| Item detail | `ui/screens/item/ItemDetailScreen.kt`, `ItemDetailViewModel.kt`, `ItemScheduleActions.kt`, `ItemTypeConversion.kt` | Separate reminder rows; observe the item live (B10) |
| Settings | `ui/screens/settings/SettingsHome.kt`, `AppearanceSettings.kt`, `AiSettingsCard.kt`, `AiSettingsViewModel.kt`, `CaptureReminderSettings.kt`, `LocalDataSettings.kt`, `LocalDataToolsViewModel.kt` | Groups with values; Appearance with glass choice; B8; B9; **erase everything (B5)** |
| Theme | `ui/theme/Theme.kt`, `Type.kt`, `DesignTokens.kt`, `ColorReadability.kt`, `res/font/`, `assets/licenses/` | Tokens; Literata + Noto Sans; licences |
| Glass and background | `ui/components/GlassSurface.kt`, `OrbitBackground.kt`, `res/drawable-nodpi/` | One glass surface (tab bar) with Frosted and Solid fallbacks; content solid; built-in backgrounds with a per-image wash; remove gradient presets, photo picker and photo error states |
| Settings data | `domain/model/AppSettings.kt`, `data/repository/AppSettingsRepository.kt` | One-time conversion of old appearance values (section 7.17), with a unit test for every old value; restore uses the same conversion |
| Outside the app | `reminders/ReminderNotifier.kt`, `capture/NewThoughtTileService.kt`, `res/xml/shortcuts.xml`, manifest, `res/mipmap*` | Keep-mark icons, "Keep in Tallele" share label, splash |
| Words | `res/values/strings*.xml`, `values-et/`, `values-ru/` | All new copy in English, Estonian and Russian |

### 10.3 Shared parts to build

`KeepMark` · `KeepButton` · `CaptureBox` · `Receipt` · `DecisionCard` · `ItemRow` · `FactRow` · `SectionHeader` · `ChoiceSheet` · `SourceRow` · `ReminderStatus` · `UndoMessage` · `TalleleTabBar` (glass / frosted / solid) · `DayAgenda`

Each part gets its state from its owner. No part guesses whether a save or a schedule worked.

### 10.4 Limits to respect

- The current build: minSdk 26, targetSdk 36, Compose BOM 2024.12.01, Navigation 2.8.5, Room 2.7.1, WorkManager 2.10.0, Haze 1.7.2, portrait only. Don't assume newer APIs.
- Targeting SDK 36 makes edge-to-edge and predictive Back mandatory. Test with gesture and three-button navigation.
- No database migration is assumed. Confirm IDs, capture-to-item links and search speed before deciding that.
- Update the docs afterwards: product rules and AI contract (filing with Undo), visual system, glass system, appearance reference, Calendar spec and Reset scope.

---

## 11. How we know it's done

Every check runs on a real phone, in light and dark, in English, Estonian and Russian.

**Capture and trust**
- With airplane mode on, a thought can be kept and found again.
- "Kept" appears only after the database confirms. A forced failure keeps the text and Try again creates no duplicate.
- Two quick saves with out-of-order sorting update the right receipts.
- Undo after automatic filing returns a kept thought and late sorting doesn't re-file it.
- Voice never keeps by itself.

**Finding**
- A kept thought, a note, a task and a reminder can each be found by a remembered word, with no extra switch.
- A sorted thought never appears twice. Brain Dump's one-to-many results show correctly.
- Query, filters and scroll come back after opening a result.

**Reminders**
- A missing or past time offers only valid choices.
- Due, notification time, repeat and real scheduling state show separately.
- Blocked notifications never show "scheduled". Done, Snooze 15 min, reboot and clock changes keep working.

**Navigation**
- A new person finds Capture, Kept thoughts, an old note, Calendar and a reminder to fix without help.
- Calendar opens from the Today link and from Saved, and returns to where it came from.
- Badge counts only To decide.

**Glass and look**
- The tab bar is Glass on Android 13+ phones and falls back to Frosted on older phones, in battery saver and with animations off.
- Tab labels pass contrast over the darkest content in all three bar settings.
- Lists, cards and sheets are never see-through.
- After the update, every old appearance value converts to its new choice without a crash, and an old backup file still restores.
- Each built-in background, light and dark, passes contrast for main and secondary text on Capture.
- Startup and Capture frame times are no worse than today.

**Data**
- Export warns that the file is readable and confirms the write.
- Restore checks first and clearly replaces.
- **Erase everything** removes items, Spaces, reminders, settings, Gemini key, learned rules and AI history, cancels every alarm, and the app opens like a new install.
- Reset appearance, Clear learned data and Erase everything each do only their own job.

**Small screens, large text, TalkBack**
- 320, 360, 390 and 412 dp widths, font size from 100% to 200%: nothing clips or overlaps, and Keep stays above the keyboard.
- TalkBack can do capture, search, reminder repair, a Space change, backup, restore and erase.
- Every swipe or long-press has a visible button or menu item too.
- With "Remove animations" on, nothing moves.

**Usability tasks (before release)**

| Task | Success looks like |
|---|---|
| Keep a quick thought | Done without choosing a type or Space; the person knows it was kept |
| Find an unsorted thought days later | Found through Saved or Search without help |
| Fix a reminder with no time | A valid time is chosen and the person can say whether it will really notify |
| Find what's on Thursday | Calendar found quickly from Today or Saved |
| Undo a wrong automatic filing | Change or Undo found; the person knows what is still saved |

---

## 12. Still open

1. **Show the original thought (B12).** Useful for trust, but it touches the rule that raw thoughts stay private.
2. **Search speed** with many kept thoughts. Measure it with a large test set.
3. **Literata at 17 sp** on small, low-density screens. Test reading speed; keep a sans option ready.
4. **Calendar without a tab.** Watch whether the Today link is enough now that the week strip is gone. If people use Calendar every day, a fourth tab can return without changing the rest.
5. **After Erase everything,** should the starter Spaces be created again, like a fresh install? The current first launch creates them.
6. **Limestone background vs None.** The Limestone light image is very close to plain paper. Keep it as a subtle texture, or swap it for something more different.
7. **Docs vs code:** the written product rules forbid silent filing, but the app files automatically. Rewrite the rules to "files automatically, always visible, always undoable".
8. **Needs a phone:** glass on weaker Android 13 phones, notification looks on different brands, TalkBack wording in Estonian and Russian, the exact Material 3 version inside BOM 2024.12.01.

---

## 13. Sources

| Source | What it gave this proposal |
|---|---|
| *Tallele — Consolidated UI & UX Redesign* (Limestone Harbour, HTML) | The base: tabs, journeys, receipt table, state rules, search scope, build phases, checks |
| *Tallele — UI & UX Redesign Proposal* (Limestone & Ink, 47-page PDF) | Colour tokens and contrast numbers, glass tab bar settings, keep mark, Keep/Kept words, B1–B11 code findings, file map |
| *Tallele Redesign Proposal* (Harbour, HTML) | Calm writing-first Capture, ink margin line, Ask and Overview modes, Calendar under Saved, month-view fallback |
| *tallele-redesign-proposal.md* + wireframes (Oxblood & Linen) | Due vs notify rows, "Keep without a reminder", shared state contract, data-safety wording |
| Owner decisions, 13–14 October 2026 | Week strip removed, glass kept, Reset erases everything, kept thoughts as "waiting", Space "+" screen |

All four proposals read the same code commit (`43a1642…`) without building or running the app. Treat every code finding as something to confirm in P0 before relying on it.
